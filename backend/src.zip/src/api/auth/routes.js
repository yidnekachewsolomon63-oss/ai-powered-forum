// import express from "express";
// import authRoutes from "./auth/routes/auth.routes.js";

// export const mainRouter = express.Router();

// // Authentication routes
// mainRouter.use("/auth", authRoutes);
import express from "express";

const router = express.Router();

router.get("/test", (req, res) => {
  res.status(200).json({
    success: true,
    message: "API is working",
  });
});

export default router;
